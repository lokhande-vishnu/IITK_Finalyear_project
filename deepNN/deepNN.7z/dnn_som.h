#ifndef DNN_SOM_H_INCLUDED
#define DNN_SOM_H_INCLUDED
#include "allstructs.h"

void dnn_som(std::vector<DATA> &data,int n_units);

#endif // DNN_SOM_H_INCLUDED
