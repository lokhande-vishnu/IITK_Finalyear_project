#ifndef DNN_UPDATEW_H_INCLUDED
#define DNN_UPDATEW_H_INCLUDED
#include "allstructs.h"

void dnn_updateW(NET &NN,const std::vector<double> &u);

#endif // DNN_UPDATEW_H_INCLUDED
