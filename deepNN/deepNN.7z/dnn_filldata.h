#ifndef DNN_FILLDATA_H_INCLUDED
#define DNN_FILLDATA_H_INCLUDED
#include <vector>
#include "allstructs.h"

void dnn_filldata(std::vector<DATA> &data,bool train);



#endif // DNN_FILLDATA_H_INCLUDED
