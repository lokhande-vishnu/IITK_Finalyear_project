#ifndef DNN_INIT_H_INCLUDED
#define DNN_INIT_H_INCLUDED
#include<vector>
#include "allstructs.h"

NET dnn_init(std::vector<int> Nn);


#endif // DNN_INIT_H_INCLUDED
