#ifndef DNN_TEST_H_INCLUDED
#define DNN_TEST_H_INCLUDED
#include "allstructs.h"

std::vector<double> dnn_test(const NET &NN, std::vector<DATA> &test);

#endif // DNN_TEST_H_INCLUDED
